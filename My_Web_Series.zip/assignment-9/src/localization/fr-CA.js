export default {
  title: "ˈtaɪtə",
  director: "dɪˈrɛktəʳ",
  stars: "étoile",
  streaming: "ˈstriːmɪŋ",
  add: "æd",
};
