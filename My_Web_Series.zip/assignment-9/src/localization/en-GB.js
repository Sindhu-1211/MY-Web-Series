export default{
    title: "title",
    director:"director",
    stars:"stars",
    streaming:"streaming",
    add:"Add"
}