export default{
    title: "ˈtaɪtl",
    director:"directeur",
    stars:"staʀ",
    streaming:"stʀimiŋ",
    add:"æd"
}